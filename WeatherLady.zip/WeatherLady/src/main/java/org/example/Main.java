package org.example;

import org.example.entity.Location;
import org.example.entity.WeatherParameters;
import org.example.entity.WindEntity;
import org.example.service.LocationService;
import org.example.service.WeatherResponse;
import org.example.service.WeatherService;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.persistence.EntityManager;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    private static final String DATABASE = "hibernate.cfg.xml";


    public static void main(String[] args) throws IOException {
    }
}



